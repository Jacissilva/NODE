Executar projeto baixado
Instalar as dependências
### `npm install install`

Rodar o projeto React
### `npm rum dev`