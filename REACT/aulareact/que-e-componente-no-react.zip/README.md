Instalar as dependências
npm install

Rodar o projeto
npm start