import React from 'react';

class Headers extends React.Component{
    render(){
        return(
            <h2>Cabeçalho</h2>
        );
    }
}

export default Headers;