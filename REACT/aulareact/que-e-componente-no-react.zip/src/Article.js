import React from 'react';

class Article extends React.Component {
    render() {
        return (
            <div>
                <h3>Titulo do artigo</h3>
                <p>Conteúdo do artigo</p>
            </div>
        );
    }
}

export default Article;