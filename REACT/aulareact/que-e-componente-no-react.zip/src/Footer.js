import React from 'react';

class Footer extends React.Component{
    render(){
        return(
            <div>
            <h4 style={{color: "green"}}>Rodapé 1</h4>
            <h4 style={{color: "#0000FF"}}>Rodapé 2</h4>
            </div>
        );
    }
}

export default Footer;