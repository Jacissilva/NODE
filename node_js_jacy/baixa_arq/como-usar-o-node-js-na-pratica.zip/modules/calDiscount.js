var discount = function(valProd, valDisc){
    return valProd - valDisc;
}

module.exports = discount;